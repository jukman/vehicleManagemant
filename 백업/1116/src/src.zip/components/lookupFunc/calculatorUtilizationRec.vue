<template>
 <div>  
   <div>보인0다</div>
   <div>보인0다</div>
   <div>보인0다</div>
   <div>보인0다</div>
    <div><h1>  go2</h1></div>
   
 </div>
</template>
<script>
// import config from "../config.js"
export default {
  data() {
    return {      
        }      
  },
  methods: {
  },
  created() {   
  }
}
</script>
<style>
</style>
